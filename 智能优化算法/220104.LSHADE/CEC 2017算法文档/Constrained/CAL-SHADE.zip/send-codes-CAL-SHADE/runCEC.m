function [x, f, fv, cbestcurr, cV] = Ldemo()
clc; clear all;
tic;
format long e; %format compact;

RNiENV = str2num(getenv('RNi'));
fileID = fopen(strcat('results-', getenv('RNi'), '.txt'),'w');
fileIDreport = fopen(strcat('report-', getenv('RNi'), '.txt'),'w');

luCEC2017=[-100 100; -100 100; -100 100; -10 10; -10 10; -20 20; -50 50; -100 100; -10 10; -100 100; -100 100; -100 100; -100 100; -100 100; -100 100; -100 100; -100 100; -100 100; -50 50; -100 100; -100 100; -100 100; -100 100; -100 100; -100 100; -100 100;  -100 100; -50 50];


for n = [10 30 50 100] % n: the dimension of the problem - 10, 30, 50, 100
MAXFES = 20000*n; % MAXFES: number of function evaluations (simulator runs) to use
%MAXFES = 200; % MAXFES: number of function evaluations (simulator runs) to use

% popsize, pmax, and NPmin are from the EUROCAST 2015 / LNCS paper
popsize=100; % popsize: population size
pmax=2;     % max. number of population size reductions
NPmin=20;   % minimal popsize after a reduction

global initial_flag;
initial_flag = 0;

global CEC2017_func_num__bench;
CEC2017_func_num__bench = 1;


%% new code for DE constraints - BEGIN
Tc = 500;
Cp = 5; % diminishing
thetaEpsilonPopAdj = 0.8;
%% new code for DE constraints - END

for CEC2017_func_num__bench = 1:28
%for CEC2017_func_num__bench = 22:22
initial_flag = 0;  
lu = [luCEC2017(CEC2017_func_num__bench) * ones(1, n); luCEC2017(size(luCEC2017,1) + CEC2017_func_num__bench) * ones(1, n)]; % lu: the upper and lower bounds of the variables

%for RNi = 1:25 % independent run number
for RNi = RNiENV:RNiENV % independent run number, obtained from environment variable (for trivial parallelization)


[X, f, fV, fMV, fSDV, cbestcurr, cV] = CALSHADE(@demoFitness, lu, MAXFES, [ 2, RNi, 0.11, 5, 1.4, 0.0001, Tc, Cp, thetaEpsilonPopAdj, fileIDreport]);
%cV
fprintf(fileID,'CALSHADE FUN%02d DIM%03d RN%02d %f %f ',CEC2017_func_num__bench,n,RNi, f, cbestcurr(1));
for col=2:size(cbestcurr, 2)
fprintf(fileID, '%f ', cbestcurr(col));
end
fprintf(fileID,'\n');

end
end
end

toc; %measure time
fclose(fileID);

%%%% Please be aware, the results must be one element in each row
function [f, g, h] = demoFitness(x)
global CEC2017_func_num__bench;
[f,g,h]=CEC2017(x,CEC2017_func_num__bench);

