% This file was edited by A. Zamuda on 5 September 2016:
% - L-SHADE functionality is now exposed as a function
% - random generator initialization uses RNi now
% - the val_2_reach is now disabled, "optimum" removed
% - lines 62 and 142: the evaluation population is now not transposed (')
% The original file archive was downloaded from
% https://sites.google.com/site/tanaberyoji/software/LSHADE1.0.1_CEC2014_Octave-Matlab.zip?attredirects=0&d=1

function [X, f, fV, fMV, fSDV, cbestcurr, cV] = CALSHADE(fitness_func, lu, MAXFES, iParams)
% X - the optimal values returned
% f - the fitness value of the optimal values returned
% fitness_func - handle to the fitness function, which evaluates a population (array) of vectors
% lu - lower and upper limit (two vectors)
% MAXFES - maximal number of fitness evaluations to use
% iParams
%   1. popsizeMult - population size multiplier
%   2. RNi - independent run number
%   3. p_best_rate - L-SHADE mutation index p-best population part rate
%   4. memory_size - parameters memory size
%   5. arc_rate - archive raze
%   6. epsfeasible - feasibility epsilon value for constraint violations, default 0.0001 CEC2017
%   7.-9. Tc, Cp, thetaEpsilonPopAdj - parameters of the constraint handling mechanism
%   10: file for report TXT (disable/comment-out this feature for faster execution)

popsizeMult = iParams(1);
RNi = iParams(2);
p_best_rate = iParams(3);
memory_size = iParams(4); % default in L-SHADE: 5
arc_rate = iParams(5); % default in L-SHADE: 1.4;
epsfeasible = iParams(6); % new CODE LINE - constr. handl.
Tc=iParams(7);
Cp=iParams(8);
thetaEpsilonPopAdj=iParams(9);
fileIDreport=iParams(10);

n = size(lu, 2);
rand('seed', 42+RNi);
randn('seed', 42+RNi);

problem_size = n;
pop_size = popsizeMult * problem_size;

max_nfes = MAXFES;
fhd=fitness_func; %fhd=@cec14_func;
% val_2_reach = 10^(-8); ! COMMENTED OUT BY A. ZAMUDA, preventing over-good false results
FITNESSVALMAX=1e+30;

fV = zeros( round( MAXFES / floor( (pop_size+1) / 2 ) ), 1 );
fMV = fV; fSDV = fV;
fbests = [];
splitcbests = -1;
progressNPsz = [];
g = 1;



%%%%%%%%%%%%%%%%%%%
%% This package is a MATLAB/Octave source code of L-SHADE which is an improved version of SHADE 1.1.
%% Note that this source code is transferred from the C++ source code version.
%% About L-SHADE, please see following papers:
%%
%% * Ryoji Tanabe and Alex Fukunaga: Improving the Search Performance of SHADE Using Linear Population Size Reduction,  Proc. IEEE Congress on Evolutionary Computation (CEC-2014), Beijing, July, 2014.
%%
%% For this package, we downloaded JADE's source code from Dr. Q. Zhang's website (http://dces.essex.ac.uk/staff/qzhang) and modified it.
%%
%% Update
%% 9/Oct/2014: incompatibilities-fix between Octave and Matlab and bug-fix of population size reduction procedure (thanks to Dr. Elsayed)
%%%%%%%%%%%%%%%%%%%

%for func = 1 : 30
%% Record the best results
outcome = [];

%  for run_id = 1 : 51
%%  parameter settings for L-SHADE
%p_best_rate = 0.11;
%arc_rate = 1.4;
%memory_size = 5;

max_pop_size = pop_size;
min_pop_size = 4.0;

%% Initialize the main population
popold = repmat(lu(1, :), pop_size, 1) + rand(pop_size, problem_size) .* (repmat(lu(2, :) - lu(1, :), pop_size, 1));
pop = popold; % the old population becomes the current population

%% NEW CODE BLOCK: constraint handling - BEGIN
%[cParents, fitness] = feval(fhd,pop); % code generalization by A. Zamuda
[fitness, constrG, constrH] = feval(fhd,pop); % code generalization by A. Zamuda %%%UGPP-check
cParents = aggregate_constraints(constrG, constrH, epsfeasible);

epsZero = constr_eps_init( pop, cParents, fitness );
vEpsilon = epsZero;
%% NEW CODE BLOCK: constraint handling - END

nfes = 0;
bsf_fit_var = FITNESSVALMAX;
bsc_constr_aggrvar = FITNESSVALMAX; % new CODE LINE - constr. handl.
bsc_constr_fullvect = [];
bsf_solution = zeros(1, problem_size);

%%%%%%%%%%%%%%%%%%%%%%%% for out
for i = 1 : pop_size
    nfes = nfes + 1;

%% NEW CODE BLOCK: constraint handling - BEGIN
    if isBetterFirst(fitness(i), cParents(i), bsf_fit_var, bsc_constr_aggrvar, vEpsilon)
        bsf_fit_var = fitness(i);
        bsc_constr_aggrvar = cParents(i);
        bsc_constr_fullvect = [ cParents(i) constrG(i,:) constrH(i,:)];
        bsf_solution = pop(i, :);
    end
%% NEW CODE BLOCK: constraint handling - END
    
    %% if mod(nfes, 1000) == 0
    %% bsf_error_var = bsf_fit_var  - optimum;
    %% if bsf_error_var < val_2_reach; bsf_error_var = 0; end;
    %%	fprintf(sprintf('%1.16e \n', bsf_error_var));
    %%    fprintf(sprintf('%d %1.16e \n', nfes, bsf_error_var));
    %% end
    
    %%      if nfes > max_nfes; exit(1); end
    if nfes > max_nfes; break; end
end
%%%%%%%%%%%%%%%%%%%%%%%% for out

% reporting code by A. Zamuda - BEGIN
fV(g) = bsf_fit_var;
fMV(g) = mean(fitness); 
fSDV(g) = std(fitness);
%% NEW CODE BLOCK: constraint handling - BEGIN
cV = zeros(MAXFES, size(bsc_constr_fullvect, 2));
%% NEW CODE BLOCK: constraint handling - END
% reporting code by A. Zamuda - END

memory_sf = 0.5 .* ones(memory_size, 1);
memory_cr = 0.5 .* ones(memory_size, 1);
memory_pos = 1;

archive.NP = arc_rate * pop_size; % the maximum size of the archive
archive.pop = zeros(0, problem_size); % the solutions stored in the archive
archive.funvalues = zeros(0, 1); % the function value of the archived solutions
archive.cParents = zeros(0, 1); % the constraint value of the archived solutions % new CODE LINE - constr. handl.

% Timing
tic
%stepShow = max_nfes/10;
stepShow = max_nfes / 3;
nFESShow = 0;

%% main loop
while nfes < max_nfes
    pop = popold; % the old population becomes the current population
    
    %% NEW CODE BLOCK: constraint handling - BEGIN
    %[temp_fit, sorted_index] = sort(fitness, 'ascend');
    cParentsV=cParents;cParentsV(cParentsV<vEpsilon)=0;
    [~, sorted_index] = sortrows([cParentsV, fitness], [1 2]);
    %% NEW CODE BLOCK: constraint handling - END
    
    mem_rand_index = ceil(memory_size * rand(pop_size, 1));
    mu_sf = memory_sf(mem_rand_index);
    mu_cr = memory_cr(mem_rand_index);
    
    %% for generating crossover rate
    cr = normrnd(mu_cr, 0.1);
    term_pos = find(mu_cr == -1);
    cr(term_pos) = 0;
    cr = min(cr, 1);
    cr = max(cr, 0);
    
    %% for generating scaling factor
    sf = mu_sf + 0.1 * tan(pi * (rand(pop_size, 1) - 0.5));
    pos = find(sf <= 0);
    
    while ~ isempty(pos)
        sf(pos) = mu_sf(pos) + 0.1 * tan(pi * (rand(length(pos), 1) - 0.5));
        pos = find(sf <= 0);
    end
    
    sf = min(sf, 1);
    
    r0 = [1 : pop_size];
    popAll = [pop; archive.pop];
    [r1, r2] = gnR1R2(pop_size, size(popAll, 1), r0);
    
    pNP = max(round(p_best_rate * pop_size), 2); %% choose at least two best solutions
    randindex = ceil(rand(1, pop_size) .* pNP); %% select from [1, 2, 3, ..., pNP]
    randindex = max(1, randindex); %% to avoid the problem that rand = 0 and thus ceil(rand) = 0
    pbest = pop(sorted_index(randindex), :); %% randomly choose one of the top 100p% solutions
    
    vi = pop + sf(:, ones(1, problem_size)) .* (pbest - pop + pop(r1, :) - popAll(r2, :));
    vi = boundConstraint(vi, pop, lu);
    
    mask = rand(pop_size, problem_size) > cr(:, ones(1, problem_size)); % mask is used to indicate which elements of ui comes from the parent
    rows = (1 : pop_size)'; cols = floor(rand(pop_size, 1) * problem_size)+1; % choose one position where the element of ui doesn't come from the parent
    jrand = sub2ind([pop_size problem_size], rows, cols); mask(jrand) = false;
    ui = vi; ui(mask) = pop(mask);
    
    [offspring_fitness, offspring_constrG, offspring_constrH] = feval(fhd, ui); % code generalization by A. Zamuda %%%UGPP-check
    cOffspring = aggregate_constraints(offspring_constrG, offspring_constrH, epsfeasible); % new CODE LINE - constr. handl.

    %%%%%%%%%%%%%%%%%%%%%%%% for out
    for i = 1 : pop_size
        nfes = nfes + 1;

%% NEW CODE BLOCK: constraint handling - BEGIN
        if isBetterFirst(offspring_fitness(i), cOffspring(i), bsf_fit_var, bsc_constr_aggrvar, vEpsilon)
            bsf_fit_var = offspring_fitness(i);
            bsc_constr_aggrvar = cOffspring(i);
            bsc_constr_fullvect = [ cOffspring(i) offspring_constrG(i,:) offspring_constrH(i,:)];
            bsf_solution = ui(i, :);
        end
%% NEW CODE BLOCK: constraint handling - END        
        
        %% if mod(nfes, 1000) == 0
        %% bsf_error_var = bsf_fit_var  - optimum;
        %% if bsf_error_var < val_2_reach; bsf_error_var = 0; end;
        %%       fprintf(sprintf('%1.16e \n', bsf_error_var));
        %%       fprintf(sprintf('%d %1.16e \n', nfes, bsf_error_var));
        %%end
        
        %%	if nfes > max_nfes; exit(1); end
        if nfes > max_nfes; break; end
    end
    %%%%%%%%%%%%%%%%%%%%%%%% for out
    new_fes = i;
    
    dif = FITNESSVALMAX * abs(cParents - cOffspring) + abs(fitness - offspring_fitness);
    %dif = abs(cParents - cOffspring);
    %if max(dif)==0   
    %    dif = abs(fitness - offspring_fitness);
    %end
    
    %% I == 1: the parent is better; I == 2: the offspring is better
    %% NEW CODE BLOCK: constraint handling - BEGIN
    % remove constraints below vEpsilon
    cParentsV   = cParents;   cParentsV  (cParentsV   < vEpsilon) = 0;
    cOffspringV = cOffspring; cOffspringV(cOffspringV < vEpsilon) = 0;
    % but keep fitness importance >1e+8 constraints
    cParentsV   = cParentsV*FITNESSVALMAX   + fitness;
    cOffspringV = cOffspringV*FITNESSVALMAX + offspring_fitness;
    % find out the min indices based on Vconstrant&fitness comparison
    %I = (fitness > offspring_fitness);
    [~, I] = min([cParentsV, cOffspringV], [], 2);
%% NEW CODE BLOCK: constraint handling - END    
        
    goodCR = cr(I == 1);
    goodF = sf(I == 1);
    dif_val = dif(I == 1);
    
    %      isempty(popold(I == 1, :))
    archive = updateArchive(archive, popold(I == 1, :), fitness(I == 1), cParents(I == 1));
    
    %[fitness, I] = min([fitness, offspring_fitness], [], 2);
    fitness(I == 2, :) = offspring_fitness(I == 2, :);
    cParents(I == 2, :) = cOffspring(I == 2, :);
    
    popold = pop;
    popold(I == 2, :) = ui(I == 2, :);
    
    num_success_params = numel(goodCR);
    
    if num_success_params > 0
        sum_dif = sum(dif_val);
        dif_val = dif_val / sum_dif;
        
        %% for updating the memory of scaling factor
        memory_sf(memory_pos) = (dif_val' * (goodF .^ 2)) / (dif_val' * goodF);
        
        %% for updating the memory of crossover rate
        if max(goodCR) == 0 || memory_cr(memory_pos)  == -1
            memory_cr(memory_pos)  = -1;
        else
            memory_cr(memory_pos) = (dif_val' * (goodCR .^ 2)) / (dif_val' * goodCR);
        end
        
        memory_pos = memory_pos + 1;
        if memory_pos > memory_size;  memory_pos = 1; end
    end
    
    %% for resizing the population size
    plan_pop_size = round((((min_pop_size - max_pop_size) / max_nfes) * nfes) + max_pop_size);
    
    if pop_size > plan_pop_size
        reduction_ind_num = pop_size - plan_pop_size;
        if pop_size - reduction_ind_num <  min_pop_size; reduction_ind_num = pop_size - min_pop_size;end
        
        pop_size = pop_size - reduction_ind_num;
        for r = 1 : reduction_ind_num
%% NEW CODE BLOCK: constraint handling - BEGIN
            %[valBest, indBest] = sort(fitness, 'ascend');
            cParentsV=cParents;cParentsV(cParentsV<vEpsilon)=0;
            [~, indBest] = sortrows([cParentsV, fitness], [1 2]);
%% NEW CODE BLOCK: constraint handling - END
            
            worst_ind = indBest(end);
            popold(worst_ind,:) = [];
            pop(worst_ind,:) = [];
            fitness(worst_ind,:) = [];
            cParents(worst_ind,:) = [];
        end
        
        archive.NP = round(arc_rate * pop_size);
        
        if size(archive.pop, 1) > archive.NP
            rndpos = randperm(size(archive.pop, 1));
            rndpos = rndpos(1 : archive.NP);
            archive.pop = archive.pop(rndpos, :);
        end
    end
    
    % % reporting code by A. Zamuda - BEGIN
    g = g + 1;
    fV(g) = bsf_fit_var;
    fMV(g) = mean( fitness );
    fSDV(g) = std( fitness );    
    %cV(g) = bsc_constr_aggrvar;
    cV(g,:) = bsc_constr_fullvect; % new CODE LINE - constr. handl.
    % % reporting code by A. Zamuda - END    
    
    %%% Timing - BEGIN
    nFESShow = nFESShow + new_fes;
    if nFESShow > stepShow 
        nFESShow = 0;
        
        fprintf('%s: Completed %d %%. fitness=%f. constraggr=%f\n', mfilename, round(nfes/max_nfes*100), fV(g), cV(g));
        et = toc;
        fprintf('\tEstimated %.1f min to finish\n', et*(max_nfes-nfes)/stepShow/60);
        tic                   
    end    
    %%% Timing - END

    %%% Report format - BEGIN
    global CEC2017_func_num__bench;
    fprintf(fileIDreport,'CALSHADE FES %02d FUN%02d DIM%03d RN%02d %f %f ', nfes, CEC2017_func_num__bench, n, RNi, bsf_fit_var, bsc_constr_fullvect(1));
    for col=2:size(bsc_constr_fullvect, 2)
       fprintf(fileIDreport, '%f ', bsc_constr_fullvect(col));
    end
    fprintf(fileIDreport,'\n');
    %%% Report format - END
    
   vEpsilon = constr_eps_adjust(epsZero, pop, fitness, cParents, nfes/max_nfes, g, Tc, Cp, thetaEpsilonPopAdj);
 
end % WHILE evolution END

% changed by A. Zamuda: disabling val_2_reach! - BEGIN
%    bsf_error_val = bsf_fit_var - optimum;
%    if bsf_error_val < val_2_reach
%        bsf_error_val = 0;
%    end
% changed by A. Zamuda: disabling val_2_reach! - END

%outcome = [outcome bsf_fit_var];

% changed by A. Zamuda: RETURN variables L-SHADE - BEGIN
fV = fV(1:g);
cV = cV(1:g,:); %%%UGPP-check: cV = cV(1:g);
fMV = fMV(1:g);
fSDV = fSDV(1:g);

X = bsf_solution; %[ DdynBest bestit]; % @PATCHvarDim: concatenate Ddyn & bearings/depths
f = bsf_fit_var; % fV(end);
cbestcurr = bsc_constr_fullvect; % new CODE LINE - constr. handl.
%cbestcurr = cV(end);
% changed by A. Zamuda: RETURN variables L-SHADE - END


function cAggr = aggregate_constraints(constrG, constrH, epsfeasible)
% Aggregates constraint violations to a single number, for comparison among
% solutions (weighted single-objective function resulting a scalar float)
% constrG - inequality constraints violation values vector
% constrH - equality constraints violation values vector
% epsfeasible - violation value that is still feasible for each constraint 

constrG(constrG<0)=0;
constrH=abs(constrH);
constrH(constrH<=epsfeasible)=0; % e.g. epsfeasible = 0.0001
cAggr=mean([constrG constrH], 2);



% changed by A. Zamuda: INSERTING BELOW FEW FILES of Matlab L-SHADE - BEGIN
% COMMENT: below, the giles "gnR1R2.m", "updateArchive.m"
% are inserted into this single file for ease of use. These files match
% the JADE code and can be plugged into the framework similarly as all
% other meta-heuristics already included.
% changed by A. Zamuda: INSERTING BELOW FEW FILES of Matlab L-SHADE - END


% changed by A. Zamuda: INSERTED FILE gnR1R2.m of Matlab L-SHADE - BEGIN
function [r1, r2] = gnR1R2(NP1, NP2, r0)

% gnA1A2 generate two column vectors r1 and r2 of size NP1 & NP2, respectively
%    r1's elements are choosen from {1, 2, ..., NP1} & r1(i) ~= r0(i)
%    r2's elements are choosen from {1, 2, ..., NP2} & r2(i) ~= r1(i) & r2(i) ~= r0(i)
%
% Call:
%    [r1 r2 ...] = gnA1A2(NP1)   % r0 is set to be (1:NP1)'
%    [r1 r2 ...] = gnA1A2(NP1, r0) % r0 should be of length NP1
%
% Version: 2.1  Date: 2008/07/01
% Written by Jingqiao Zhang (jingqiao@gmail.com)

NP0 = length(r0);

r1 = floor(rand(1, NP0) * NP1) + 1;
%for i = 1 : inf
for i = 1 : 99999999
    pos = (r1 == r0);
    if sum(pos) == 0
        break;
    else % regenerate r1 if it is equal to r0
        r1(pos) = floor(rand(1, sum(pos)) * NP1) + 1;
    end
    if i > 1000, % this has never happened so far
        error('Can not genrate r1 in 1000 iterations');
    end
end

r2 = floor(rand(1, NP0) * NP2) + 1;
%for i = 1 : inf
for i = 1 : 99999999
    pos = ((r2 == r1) | (r2 == r0));
    if sum(pos)==0
        break;
    else % regenerate r2 if it is equal to r0 or r1
        r2(pos) = floor(rand(1, sum(pos)) * NP2) + 1;
    end
    if i > 1000, % this has never happened so far
        error('Can not genrate r2 in 1000 iterations');
    end
end
% changed by A. Zamuda: INSERTED FILE gnR1R2.m of Matlab L-SHADE - END

% changed by A. Zamuda: INSERTED FILE updateArchive.m of Matlab L-SHADE - BEGIN
function archive = updateArchive(archive, pop, funvalue, cParents)
% Update the archive with input solutions
%   Step 1: Add new solution to the archive
%   Step 2: Remove duplicate elements
%   Step 3: If necessary, randomly remove some solutions to maintain the archive size
%
% Version: 1.1   Date: 2008/04/02
% Written by Jingqiao Zhang (jingqiao@gmail.com)

if archive.NP == 0, return; end

if size(pop, 1) ~= size(funvalue,1), error('check it'); end

% Method 2: Remove duplicate elements
popAll = [archive.pop; pop ];
funvalues = [archive.funvalues; funvalue ];
[dummy IX]= unique(popAll, 'rows');
if length(IX) < size(popAll, 1) % There exist some duplicate solutions
    popAll = popAll(IX, :);
    funvalues = funvalues(IX, :);
end

if size(popAll, 1) <= archive.NP   % add all new individuals
    archive.pop = popAll;
    archive.funvalues = funvalues;
else                % randomly remove some solutions
    rndpos = randperm(size(popAll, 1)); % equivelent to "randperm";
    rndpos = rndpos(1 : archive.NP);
    
    archive.pop = popAll  (rndpos, :);
    archive.funvalues = funvalues(rndpos, :);
end
% changed by A. Zamuda: INSERTED FILE updateArchive.m of Matlab L-SHADE - END


% changed by A. Zamuda: INSERTED FILE boundConstraint.m of Matlab L-SHADE - BEGIN
function vi = boundConstraint (vi, pop, lu)

% if the boundary constraint is violated, set the value to be the middle
% of the previous value and the bound
%
% Version: 1.1   Date: 11/20/2007
% Written by Jingqiao Zhang, jingqiao@gmail.com

[NP, D] = size(pop);  % the population size and the problem's dimension

%% check the lower bound
xl = repmat(lu(1, :), NP, 1);
pos = vi < xl;
vi(pos) = (pop(pos) + xl(pos)) / 2;

%% check the upper bound
xu = repmat(lu(2, :), NP, 1);
pos = vi > xu;
vi(pos) = (pop(pos) + xu(pos)) / 2;
% changed by A. Zamuda: INSERTED FILE boundConstraint.m of Matlab L-SHADE - END



% changed by A. Zamuda: INSERTED constraint hanlding from SPSRDEMMS - BEGIN
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% epsilon-constraint initialization:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% sort violations (epsilons), ascending
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% and take the cca 20%-th
function vEpsilon = constr_eps_init(popold, valParents, cParents)
cParentsASC=sort(cParents);
percPOPidx = round(1 + size(cParents, 2) * 0.2);
vEpsilon = cParentsASC(percPOPidx);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% epsilon-constraint adjustment
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function vEpsilon = constr_eps_adjust(epsZero, popold, valParents, cParents, FESperc, g, Tc, Cp, thetaEpsilonPopAdj)
if g > Tc
    vEpsilon = 0;
    return;
end

vEpsilon = epsZero * (  1 - FESperc ) ^ Cp;

%sort violations (epsilons), ascending
cParentsASC=sort(cParents);
percPOPidx = round(1 + size(cParents, 2) * thetaEpsilonPopAdj);
vEpsilon = cParentsASC(percPOPidx);


function I = minEps(valParents, cParents, valOffspring, cOffspring, vEpsilon)
I = zeros(size(valParents, 1), 1);

for k=1:size(valParents, 1)
    I(k) = isBetterFirst(valParents(k), cParents(k), valOffspring(k), cOffspring(k), vEpsilon);
    % [valParents, I] = min([valParents, valOffspring], [], 2);
end



function whichBetter = isBetterFirst(firstVal, firstC, secondVal, secondC, vEpsilon)
%if vEpsilon > 1.e-4 && 
   
if (firstC < vEpsilon && secondC < vEpsilon) || (firstC == 0 && secondC == 0)
    if firstVal < secondVal
        whichBetter = 1;
    else
        whichBetter = 2;
    end
    return
end

if firstC < secondC
    whichBetter = 1;
else
    whichBetter = 2;
end

% Get best iteration per constraint
function [iBest, bestIt, fBest, cBest] = GetBestItPerConstraint( pop, fitV, constV, indexV )

zeroIndex = indexV(constV==0);

if isempty( zeroIndex )
    [cBest, iBest] = min( constV );
    fBest = fitV(iBest);
else
    [fBest, iBest1] = min( fitV(zeroIndex) );
    iBest = zeroIndex(iBest1);
    cBest = constV(iBest);
end
bestIt = pop(iBest, :);
% changed by A. Zamuda: INSERTED constraint hanlding from SPSRDEMMS - END

