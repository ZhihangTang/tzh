echo "run('runCEC'); exit;" |~/opt/matlab/bin/matlab
