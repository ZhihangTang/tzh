% Coded by Guohua Wu, National University of Defense Technology, guohuawu@nudt.edu.cn
function [ index ] = Compare_TwoMethods_MeanValue_OneProblem( input_X1,input_X2 )
%Compare_TwoMethods_MeanValue_OneProblem �Ƚ�����������һ�������ϻ���mean value������������
%input_X1(1)Ϊfeasibility rate, input_X1(2)Ϊmean constraint violation, input_X1(3)Ϊmean objective function value
%input_X2�Ľṹ��input_X1(1,:)��ͬ

if (input_X1(1) == input_X2(1)) && (input_X1(2) == input_X2(2)) && (input_X1(3) == input_X2(3))
    index = 0; return
end

if input_X1(1) > input_X2(1)
    index(1)=1;index(2)=2;
    return
end

if input_X1(1) < input_X2(1)
    index(1)=2;index(2)=1;
    return
end

if input_X1(2) < input_X2(2) && ~(input_X1(2) <0.0004  && input_X2(2) <0.0004 )
    index(1)=1; index(2)=2;
    return
end

if input_X1(2) > input_X2(2) && ~(input_X1(2) <0.0004  && input_X2(2) <0.0004 )
    index(1)=2; index(2)=2;
    return
end

if input_X1(3) < input_X2(3)
    index(1)=1; index(2)=2;
    return
end

if input_X1(3) > input_X2(3)
    index(1)=2; index(2)=2;
    return
end

end

