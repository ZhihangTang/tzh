% Coded by Guohua Wu, National University of Defense Technology, guohuawu@nudt.edu.cn
function [ index ] =Compare_MultiMethods_MedianSolution_OneProblem(input_V,input_Ob, num_method )
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
index = zeros(1, num_method);
sequenceIndex = 1:num_method;
equalMark = zeros(1, num_method);
for i=1:num_method
    for j=i+1:num_method
        input_X1 = [input_V(sequenceIndex(i),1),input_Ob(sequenceIndex(i),1)];
        input_X2 = [input_V(sequenceIndex(j),1),input_Ob(sequenceIndex(j),1)];
        outCome = Compare_TwoMethods_MedianSolution_OneProblem(input_X1,input_X2 );
        if outCome(1) == 2 %j�±�Ľ��i�±�Ľ��
%             swapV= input_V(i,1); swapOb = input_Ob(i,1); 
            swapSeq = sequenceIndex(i); 
%             input_V(i,1) = input_V(j,1); input_Ob(i,1) = input_Ob(j,1);
            sequenceIndex(i) = sequenceIndex(j);
%             input_V(j,1) = swapV; input_Ob(j,1) = swapOb; 
            sequenceIndex(j) = swapSeq;            
        end
        if outCome(1) ==0
           equalMark (i+1) = 1; %˵�����źú�������У���i+1��Ԫ�غ͵�i��Ԫ������ֵ��ͬ��
        end
    end    
end
for k =1:num_method
    index(sequenceIndex(k)) = k;
    if equalMark (k) == 1
        index(sequenceIndex(k)) = index(sequenceIndex(k-1)); 
    end
end

end

