% Coded by Guohua Wu, National University of Defense Technology, guohuawu@nudt.edu.cn
function [ index ] = Compare_TwoMethods_MedianSolution_OneProblem( input_X1,input_X2 )
% Compare_TwoMethods_MedianSolution_OneProblem�Ƚ�����median solution��ֵ������
%input_X1,input_X2 ��һά���飬��������Ԫ�أ���һ��Ԫ��Ϊmedian solution violation
%constraint,�ڶ���Ԫ��Ϊmedian solution ��objective function value
if (input_X1(1) == input_X2(1)) && (input_X1(2) == input_X2(2)) 
    index = 0; return
end

if (input_X1(1) < input_X2(1)) && ~(input_X1(1) <= 0.0001 && input_X2(1) <= 0.0001)
    index(1)=1;index(2)=2;
    return
end

if input_X1(1) > input_X2(1) && ~(input_X1(1) <= 0.0001 && input_X2(1) <= 0.0001)
    index(1)=2;index(2)=1;
    return
end

if ((input_X1(1) <= 0.0001 && input_X2(1) <= 0.0001) || input_X1(1) == input_X2(1)) && input_X1(2) < input_X2(2)
    index(1)=1;index(2)=2;
    return
end


if ((input_X1(1) <= 0.0001 && input_X2(1) <= 0.0001) || input_X1(1) == input_X2(1)) && input_X1(2) > input_X2(2)
    index(1)=2;index(2)=1;
    return
end
end

