% Coded by Guohua Wu, National University of Defense Technology, guohuawu@nudt.edu.cn
function [ index indexSet] =  Compare_MultiMethods_MedianSolution_MultiProblems(input_Vset,input_Obset, num_method, num_problem )
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
index = zeros(1,num_method);
indexSet = zeros(num_method,num_problem);
for i=1:num_problem
%     ithproblem = i
    singleProblem = Compare_MultiMethods_MedianSolution_OneProblem( input_Vset(:,i),input_Obset(:,i), num_method);
    index = index + singleProblem;
    indexSet(:,i) = singleProblem';
end

end

