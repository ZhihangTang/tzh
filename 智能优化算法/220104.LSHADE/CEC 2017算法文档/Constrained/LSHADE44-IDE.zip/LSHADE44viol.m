function [num_feasible, fmin, violmin, P, FES,...
    vyslrun01, vyslrun05] = ...
    LSHADE44viol(fnum,D,nasobek, maxFES,a,b, eps_viol, rnumfeas)%
rand('state',sum(100*clock));
d = D;
vyslrun01 = NaN(1,d+11);
vyslrun05 = NaN(1,d+11);
%binomialni a exponencialni krizeni soutezi ale jen v jedne generaci
N_init= nasobek * D;  % puvodne nasobek = 18
N_min = rnumfeas;
N=N_init; %aktualni velikost populace
p=0.11; %pro mutaci current-to-pbest
max_velikost_archivu=round(N*2.6);
H=6; %velikost kruhovych pameti
%
h=4; %pocet strategii v soutezi
n0=2;
delta=1/(5*h);
ni=zeros(1,h)+n0;
% inicializace:
for i = 1:N
    P(i,1:d)=(a+(b-a)).*rand(1,D);
end
[f,gineq,heq]=CEC2017(P(:,1:d),fnum);
[viol,Heq,Gineq] =violation_velke(fnum, heq,gineq,eps_viol,N);
FES=N;
P(:,d+1)= f;
P(:,d+2)= viol; % bude se minimalizovat
P = [P, Heq, Gineq]; % 0-th generation initialized
P = sortrows(P,d+2);  % viol
num_feasible = sum(P(:,d+2) == 0);
Q = P;
%inicializace vsech 4 paru kruhovych pameti
MFpbin=.5*ones(1,H);
MFpexp=.5*ones(1,H);
MCRpbin=.5*ones(1,H);
MCRpexp=.5*ones(1,H);
MFprlbin=.5*ones(1,H);
MFprlexp=.5*ones(1,H);
MCRprlbin=.5*ones(1,H);
MCRprlexp=.5*ones(1,H);
% ukazovatka v ctyrech parech kruhovych  pameti
kpbin=1;
kpexp=1;
kprlbin=1;
kprlexp=1;
%
velarchivu=0;
% A = zeros(max_velikost_archivu, d);
A=[];
%
while FES < maxFES  && num_feasible < rnumfeas  % main loop
    %vyhodnoceni populace konkurentu je provedeno v jednom kroku, proto je zapotrebi si pouzite F a CR pamatovat, pamatuji se v nasledujicich polich
    Fpole=-1*ones(1,N);
    Fpoleexp=-1*ones(1,N);
    CRpole=-1*ones(1,N);
    CRpoleexp=-1*ones(1,N);
    Fpolerl=-1*ones(1,N);
    Fpolerlexp=-1*ones(1,N);
    CRpolerl=-1*ones(1,N);
    CRpolerlexp=-1*ones(1,N);
    
    strategie=zeros(1,N); %pamatuji si i strategie
    
    %mnoziny uspesnych parametru
    SCRpbin=[];SFpbin=[];
    SCRpexp=[];SFpexp=[];
    SCRprlbin=[];SFprlbin=[];
    SCRprlexp=[];SFprlexp=[];
    %pocitadla uspesnosti pro kazdou z pouzitych strategii
    uspesnychpbin=0;
    uspesnychpexp=0;
    uspesnychprlbin=0;
    uspesnychprlexp=0;
    %nasledujici vektory slouzi k vypoctu novych prvku v kruhovych pametech
    deltafcepbin=-1*ones(1,N);
    deltafcepexp=-1*ones(1,N);
    deltafceprlbin=-1*ones(1,N);
    deltafceprlexp=-1*ones(1,N);
    %
    for i=1:N  %VYTVORENI DALSI GENERACE
        [hh,p_min]=roulete(ni);
        if p_min<delta
            ni=zeros(1,h)+n0;
        end  %reset
        r=nahvyb(H,1) ;%vyber nahodneho paru parametru z kruhove pameti
        switch hh
            case 1             %(CURRENTTORAND/BIN)
                strategie(1,i)=1;
                if MCRpbin(1,r)==-1
                    CR=0;
                else
                    CR=MCRpbin(1,r)+ sqrt(0.1)*randn(1);
                end
                if CR>1
                    CR=1;
                elseif CR<0
                    CR=0;
                end
                F=-1;
                while F<=0
                    F=rand*pi-pi/2;
                    F=0.1 * tan(F) + MFpbin(1,r);
                end
                if F>1
                    F=1;
                end
                ppoc=round(p*N);
                if ppoc==0
                    ppoc=1;
                end
                Fpole(1,i)=F;
                CRpole(1,i)=CR;
                y=currenttopbestbin_izrc(A,velarchivu,...
                    P(:,1:d),P(:,d+2), ppoc,F,CR,i,a(1),b(1));
                Q(i,1:d)=y;
            case 2      %(CURRENTTORAND/EXP)
                strategie(1,i)=2;
                if MCRpexp(1,r)==-1
                    CR=0;
                else
                    CR=MCRpexp(1,r)+ sqrt(0.1)*randn(1);
                end
                if CR>1
                    CR=1;
                elseif CR<0
                    CR=0;
                end
                F=-1;
                while F<=0
                    F=rand*pi-pi/2;
                    F=0.1 * tan(F) + MFpexp(1,r);
                end
                if F>1
                    F=1;
                end
                ppoc=round(p*N);
                if ppoc==0
                    ppoc=1;
                end
                Fpoleexp(1,i)=F;
                CRpoleexp(1,i)=CR;
                y=currenttopbestexp_izrc(A,velarchivu,P(:,1:d),P(:,d+2),...
                    ppoc,F,CR,i,a(1),b(1));
                Q(i,1:d)=y;
            case 3    %(RANDRL/BIN)
                strategie(1,i)=3;
                if MCRprlbin(1,r)==-1
                    CR=0;
                else
                    CR=MCRprlbin(1,r)+ sqrt(0.1)*randn(1);
                end
                if CR>1
                    CR=1;
                elseif CR<0
                    CR=0;
                end
                F=-1;
                while F<=0
                    F=rand*pi-pi/2;
                    F=0.1 * tan(F) + MFprlbin(1,r);
                end
                if F>1
                    F=1;
                end
                Fpolerl(1,i)=F;
                CRpolerl(1,i)=CR;
                y=derand_RLe(P(:,1:d),P(:,d+2),F,CR,i);
                Q(i,1:d)=zrcad(y,a(1),b(1));
            case 4   %(RANDRL/EXP)
                strategie(1,i)=4;
                if MCRprlexp(1,r)==-1
                    CR=0;
                else
                    CR=MCRprlexp(1,r)+ sqrt(0.1)*randn(1);
                end
                if CR>1
                    CR=1;
                elseif CR<0
                    CR=0;
                end
                F=-1;
                while F<=0
                    F=rand*pi-pi/2;
                    F=0.1 * tan(F) + MFprlexp(1,r);
                end
                if F>1
                    F=1;
                end
                Fpolerlexp(1,i)=F;
                CRpolerlexp(1,i)=CR;
                y=derandexp_RLe(P(:,1:d),P(:,d+2),F,CR,i);
                Q(i,1:d)=zrcad(y,a(1),b(1));
        end  % end switch
    end % end for (generace)
    %vypocet ucelove funkce pro matici konkurentu:
    [fkon,gineq,heq]=CEC2017(Q(:,1:d),fnum);
    [violkon,Heqkon,Gineqkon] =violation_velke(fnum, heq,gineq,eps_viol,N);
    Q(:,d+1)= fkon;
    Q(:,d+2)= violkon; % bude se minimalizovat
    Q = [Q(:,1:d+2), Heqkon, Gineqkon];
    FES=FES+N;
    for i=1:N
        if Q(i,d+2) < P(i,d+2)
            switch  strategie(1,i)
                case 1
                    deltafcepbin(1,i)=P(i,d+2)-Q(i,d+2); %pro vypocet noveho parametru ulozeneho v kruhove pameti
                    uspesnychpbin=uspesnychpbin+1; %pro vypocet noveho parametru ulozeneho v kruhove pameti
                    SCRpbin=[SCRpbin,CRpole(1,i)]; %pripsani uspesneho CR do mnoziny uspesnych v teto generaci
                    SFpbin=[SFpbin,Fpole(1,i)]; %pripsani uspesneho F do mnoziny uspesnych v teto generaci
                case 2
                    deltafcepexp(1,i)=P(i,d+2)-Q(i,d+2); %pro vypocet noveho parametru ulozeneho v kruhove pameti
                    uspesnychpexp=uspesnychpexp+1; %pro vypocet noveho parametru ulozeneho v kruhove pameti
                    SCRpexp=[SCRpexp,CRpoleexp(1,i)]; %pripsani uspesneho CR do mnoziny uspesnych v teto generaci
                    SFpexp=[SFpexp,Fpoleexp(1,i)]; %pripsani uspesneho F do mnoziny uspesnych v teto generaci
                case 3
                    deltafceprlbin(1,i)=P(i,d+2)-Q(i,d+2); %pro vypocet noveho parametru ulozeneho v kruhove pameti
                    uspesnychprlbin=uspesnychprlbin+1; %pro vypocet noveho parametru ulozeneho v kruhove pamet i
                    SCRprlbin=[SCRprlbin,CRpolerl(1,i)]; %pripsani uspesneho CR do mnoziny uspesnych v teto generaci
                    SFprlbin=[SFprlbin,Fpolerl(1,i)]; %pripsani uspesneho F do mnoziny uspesnych v teto generaci
                case 4
                    deltafceprlexp(1,i)=P(i,d+2)-Q(i,d+2); %pro vypocet noveho parametru ulozeneho v kruhove pameti
                    uspesnychprlexp=uspesnychprlexp+1; %pro vypocet noveho parametru ulozeneho v kruhove pameti
                    SCRprlexp=[SCRprlexp,CRpolerlexp(1,i)]; %pripsani uspesneho CR do mnoziny uspesnych v teto generaci
                    SFprlexp=[SFprlexp,Fpolerlexp(1,i)]; %pripsani uspesneho F do mnoziny uspesnych v teto generaci
            end
            %vepsani bodu z populace do archivu (kdyz je nahrazen lepsim)
            if velarchivu < max_velikost_archivu
                A=[A;P(i,1:d)];
                velarchivu=velarchivu+1;
            else
                ktere=nahvyb(velarchivu,1);
                A(ktere,:)=P(i,1:d);
            end
        end
        %nahrazeni bodu v populaci bodem novym, pokud je lepsi
        if Q(i, d+2) < P(i, d+2)... % mensi violation
                || (Q(i, d+2) == P(i, d+2) && Q(i, d+1) < P(i, d+1))
            % stejne violation, lepsi funkce
            P(i,:)=Q(i,:);
            ni(strategie(1,i))=ni(strategie(1,i))+1;         % zmena prsti qi
        end
    end
    %4x uprava k-te polozky v kruhove pameti
    if uspesnychpbin>0
        platne=find(deltafcepbin~=-1);
        delty=deltafcepbin(1,platne);
        suma=sum(delty);
        vahyw=1/suma*delty;
        mSCRpbin=max(SCRpbin);
        if MCRpbin(1,kpbin)==-1  ||  mSCRpbin==0
            MCRpbin(1,kpbin)=-1;
        else
            sz_vahyw = size(vahyw);
            sz_SCR = size(SCRpbin);
            if sz_vahyw(1) ~= sz_SCR(1) | sz_vahyw(2) ~= sz_SCR(2)
                FES
                sz_vahyw
                sz_SCR
            end
            MCRpbin(1,kpbin)=sum(vahyw.*SCRpbin);
        end
        meanSFpomjm=vahyw.*SFpbin;
        meanSFpomci=meanSFpomjm.*SFpbin;
        MFpbin(1,kpbin)=sum(meanSFpomci)/sum(meanSFpomjm);
        kpbin=kpbin+1;
        if kpbin>H
            kpbin=1;
        end
    end
    if uspesnychpexp>0
        platne=find(deltafcepexp~=-1);
        delty=deltafcepexp(1,platne);
        suma=sum(delty);
        vahyw=1/suma*delty;
        mSCRpexp=max(SCRpexp);
        if MCRpexp(1,kpexp)==-1  ||  mSCRpexp==0
            MCRpexp(1,kpexp)=-1;
        else
            MCRpexp(1,kpexp)=sum(vahyw.*SCRpexp);
        end
        meanSFpomjm=vahyw.*SFpexp;
        meanSFpomci=meanSFpomjm.*SFpexp;
        MFpexp(1,kpexp)=sum(meanSFpomci)/sum(meanSFpomjm);
        kpexp=kpexp+1;
        if kpexp>H
            kpexp=1;
        end
    end
    if uspesnychprlbin>0
        platne=find(deltafceprlbin~=-1);
        delty=deltafceprlbin(1,platne);
        suma=sum(delty);
        vahyw=1/suma*delty;
        mSCRprlbin=max(SCRprlbin);
        if MCRprlbin(1,kprlbin)==-1  || mSCRprlbin==0
            MCRprlbin(1,kprlbin)=-1;
        else
            sz_vahyw = size(vahyw);
            sz_SCR = size(SCRprlbin);
            if sz_vahyw(1) ~= sz_SCR(1) | sz_vahyw(2) ~= sz_SCR(2)
                FES
                sz_vahyw
                sz_SCR
            end
            MCRprlbin(1,kprlbin)=sum(vahyw.*SCRprlbin);
        end
        meanSFpomjm=vahyw.*SFprlbin;
        meanSFpomci=meanSFpomjm.*SFprlbin;
        MFprlbin(1,kprlbin)=sum(meanSFpomci)/sum(meanSFpomjm);
        kprlbin=kprlbin+1;
        if kprlbin>H
            kprlbin=1;
        end
    end
    if uspesnychprlexp>0
        platne=find(deltafceprlexp~=-1);
        delty=deltafceprlexp(1,platne);
        suma=sum(delty);
        vahyw=1/suma*delty;
        mSCRprlexp=max(SCRprlexp);
        if MCRprlexp(1,kprlexp)==-1  ||  mSCRprlexp==0
            MCRprlexp(1,kprlexp)=-1;
        else
            MCRprlexp(1,kprlexp)=sum(vahyw.*SCRprlexp);
        end
        meanSFpomjm=vahyw.*SFprlexp;
        meanSFpomci=meanSFpomjm.*SFprlexp;
        MFprlexp(1,kprlexp)=sum(meanSFpomci)/sum(meanSFpomjm);
        kprlexp=kprlexp+1;
        if kprlexp>H
            kprlexp=1;
        end
    end
    P = sortrows(P,d+2);
    %linearni zmenseni populace
    ps_minule = N;
    N = round(((N_min-N_init)/maxFES)*FES+N_init);
    if N < ps_minule
        P = P(1:N,:);
        max_velikost_archivu=round(N*2.6);
        while velarchivu > max_velikost_archivu
            index_v_arch=nahvyb(velarchivu,1);
            A(index_v_arch,:)=[];
            velarchivu=velarchivu-1;
        end
    end
    Q = P;
    num_feasible = sum(P(:,d+2) == 0);
    if FES > 2000*d -1 && FES < 2000*d + N -1
        vyslrun01  = vysl( P, d );
    end
    if FES > 10000*d -1 && FES < 10000*d + N-1
        vyslrun05  = vysl( P, d );
    end
end % end of main loop
P = sortrows(P,d+2);
if num_feasible > 0
    P2 = P(1:num_feasible,:); % jen feasible
    [fmin, indfmin] = min(P2(:, d+1));
    if indfmin > rnumfeas % fmin je pod carou
        P(1,:) = P2(indfmin,:);
    end
    % xmin = P2(indfmin, 1:d);
    violmin = 0;
else
    violmin = P(1, d+2);
    fmin = P(1, d+1);
    % xmin = P(indvmin, 1:d);
end
P = P(1:rnumfeas, :);
end
