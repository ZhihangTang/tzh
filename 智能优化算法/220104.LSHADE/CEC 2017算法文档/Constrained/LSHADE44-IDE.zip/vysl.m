function vyslrun  = vysl( P, d )
%VYSL Summary of this function goes here
%   dilci vysledky po dosazeni pozadovanych FES
num_feasible = sum(P(:,d+2) == 0);
if num_feasible > 0
    P = sortrows(P,d+2);
    P2 = P(1:num_feasible,:);
    [fmin, indfmin] = min(P2(:, d+1));
    xmin = P2(indfmin, 1:d);
    violmin = P2(indfmin, d+2);
    indvmin = indfmin;  %% jen pro kontrolni vypis
else
    [violmin, indvmin] = min(P(:, d+2));
    fmin = P(indvmin, d+1);
    xmin = P(indvmin, 1:d);
end
GH = P(indvmin, d+3:end);
% size(GH)
% size(xmin)
vyslrun = [fmin, violmin, GH, xmin];
% sz_vysl = size(vyslrun)
end

