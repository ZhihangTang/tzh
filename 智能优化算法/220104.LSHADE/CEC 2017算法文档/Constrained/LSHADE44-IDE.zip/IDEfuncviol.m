function [num_feasible, xmin, fmin, violmin, FES, succcess, GH,...
    vyslrun01, vyslrun05]=...
    IDEfuncviol(fnum, P, a, b, N, d, maxFES, FES1,  eps_viol,  eps_fun)
%
% Tvrdik, March 2016, modified November 2016
%
% initialization
% global  initial_flag
vyslrun01 = NaN(1,d+11);
vyslrun05 = NaN(1,d+11);
gmax = round(maxFES / N);   % maxFES available
FES = 0; succcess = 0;
% SRg = zeros(gmax,1) + 2;
T = gmax/10;
GT = fix(gmax / 2);
gt = gmax; % Radka opravila, puvodne GT; % auxiliary count of generation for SRT threshold
Q = P;
gen = 0;
%gt = GT;  %stage = 1;
Tcurr = 0;
violmax = max(P(:,d+2));
thresh_viol = min(P(:,d+2));
%% thresh_viol = median(P(:,d+2));  % volnejsi podminka
fmin = min(P(:,d+1));
fmax = fmin+1;
while gen < gmax  && ((fmax - fmin) > eps_fun || violmax > 0)  % main loop
    ps = 0.1 + 0.9 * 10^(5*(gen/gmax - 1)); % ratio of Superior
    pd = 0.1 * ps;  % prob. of perturbation
    if gen < gt
        SRT = 0;
    else
        SRT = 0.1;
    end
    for i=1:N  %  mutation in each generation
        vyb = nahvyb_expt(N,4, i);
        o = vyb(1);
        r1 = vyb(2);
        r2 = vyb(3);
        r3 = vyb(4);
        xo = P(o,1:d);
        xr1= P(r1,1:d);
        xr2= P(r2,1:d);
        xr3= P(r3,1:d);
        indperturb = find(rand(1,d) < pd);
        pom = a + rand(1, d) .* (b - a);
        xr3(indperturb) = pom(indperturb);
        if gen <= gt   %  !!!!!
            o = i;
        end
        Fo = o/N + 0.1 * randn(1);
        while Fo <= 0 || Fo > 1
            Fo = o/N + 0.1 * randn(1);
        end
        high_ind_S = fix(ps * N);
        if o > high_ind_S  % Inferior
            if r1 > high_ind_S  %  find "better" from Superior
                candidates = setdiff(1: high_ind_S, [vyb, i]);
                r1 = 1 + fix(rand(1) * length(candidates));
                xr1 =  P(r1,1:d);
                %               pomcounter = pomcounter +1;
            end
        end
        Q(i, 1:d) = xo + Fo*(xr1 - xo) + Fo*(xr2 - xr3);
    end % end of mutation in the current generation
    for i=1:N  %  crossover
        CR = i/N + 0.1 * randn(1);
        while CR < 0 || CR > 1
            CR = i/N + 0.1 * randn(1);
        end
        jrand = 1 + fix(rand(1)* d);
        for j=1:d
            if ~(rand(1) <= CR || j  == jrand) % take old P
                Q(i,j) = P(i,j);
            end
            if Q(i,j) < a(j) || Q(i,j) > b(j) % out of boundary
                Q(i,j) = a(j) + rand(1)*(b(j) - a(j));
            end
        end  % Q is a new generation
    end % end of crossover in the current generation
    % ??? initial_flag = 0;
    [f,g,h]=CEC2017(Q(:,1:d),fnum);
    FES = FES + N;
    [viol,H,G] =violation_velke(fnum,h,g,eps_viol,N);
    Q(:,d+1)= f;
    Q(:,d+2)= viol; % bude se minimalizovat
    Q  = [Q(:, 1:d+2), H, G];
    indsucc_viol = find(Q(:,d+2) <= thresh_viol);
    indsucc_fun  = find(Q(:,d+1) <= P(:,d+1));
    indsucc = intersect(indsucc_viol, indsucc_fun);
    % accept if violation is not worse than the old
    SR = length(indsucc) / N;
    if  gen < gt  % stage == 1
        if SR <= SRT
            Tcurr = Tcurr + 1;
        else
            Tcurr = 0;
        end
        if Tcurr >= T    %%  stage = 2;
            gt = gen; %;
            % display('stage2')
        end % a uz sem nelez
    end
    if  ~isempty(indsucc)
        P(indsucc,:) = Q(indsucc,:); % replace by better points
        succcess = succcess + length(indsucc);
    end
    P = sortrows(P,d+1);
    fmin = P(1, d+1);
    fmax = P(end, d+1);
    violmax = max(P(:,d+2));
    % thresh_viol = median(P(:,d+2));
    gen = gen + 1;
    if FES1+FES > 2000*d -1 && FES1+FES < 2000*d + N -1
        vyslrun01  = vysl( P, d );
    end
    if FES1+FES > 10000*d -1 && FES1+FES < 10000*d + N-1
        vyslrun05  = vysl( P, d );
    end
end   % main while loop - end
num_feasible = sum(P(:,d+2) == 0);
if num_feasible > 0
    P = sortrows(P,d+2);
    P2 = P(1:num_feasible,:);
    [fmin, indfmin] = min(P2(:, d+1));
    xmin = P2(indfmin, 1:d);
    violmin = P2(indfmin, d+2);
    indvmin = indfmin;  %% jen pro kontrolni vypis
else
    [violmin, indvmin] = min(P(:, d+2));
    fmin = P(indvmin, d+1);
    xmin = P(indvmin, 1:d);
end
GH = P(indvmin, d+3:end);
disp('vysl3')
FES1 + FES
end
%