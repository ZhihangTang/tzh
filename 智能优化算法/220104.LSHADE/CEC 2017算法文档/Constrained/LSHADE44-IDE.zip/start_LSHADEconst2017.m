% The Ensemble of SF SR EC and SP constraint handling methods
clear all;
global  initial_flag
initial_flag = 0;
format long e;
D = 10; d=D;%30
%N = 500;     %100
nasobek = 18;
rnumfeas = 50;
eps_viol=0.0001;
rFESviol = 0.99;
rnfeas  = 50;
eps_fun = 1e-16;
%runs = 25;
runs = 2;
Xmax = 100 + zeros(28,1);
Xmax(4) = 10;
Xmax(5) = 10;
Xmax(6) = 20;
Xmax(7) = 50;
Xmax(9) = 10;
Xmax(19) = 50;
Xmax(28) = 50;
maxFES=D*20000;
for fnum = [3,6,7]  
    % fnum= 5 % Function Number
    disp('fnum'); disp(fnum);
    b=Xmax(fnum) * ones(1,d);
    a = - b;
    fid=fopen('CEC2017_d10pok.000','a');
    vysl01pop = NaN(runs, d+11);
    vysl05pop = NaN(runs, d+11);
    vyslfinpop = NaN(runs, d+11);
    for krok=1:runs   %:25
        initial_flag = 0;
        disp('krok'); disp(krok);  %tim=cputime;
        [num_feasible1, fmin1, violmin1, P, FES1, ...
            vyslrun01, vyslrun05] = LSHADE44viol(fnum,D,...
            nasobek, maxFES*rFESviol,a,b, eps_viol, 50);
        if ~isnan(vyslrun01(1))
            vysl01pop(krok, :) = vyslrun01;
        end
        if ~isnan(vyslrun05(1))
            vysl05pop(krok, :) = vyslrun05;
        end
        maxFES_available = maxFES - FES1;
        [num_feasible, xmin, fmin, violmin, FES2, success2, GH,...
            vyslrun01, vyslrun05]=...
            IDEfuncviol(fnum, P, a, b, rnfeas, d, maxFES_available+1,...
            FES1, eps_viol,  eps_fun);
        if ~isnan(vyslrun01(1))
            vysl01pop(krok, :) = vyslrun01;
        end
        if ~isnan(vyslrun05(1))
            vysl05pop(krok, :) = vyslrun05;
        end
        vyslfinpop(krok, :) = [fmin, violmin, GH, xmin];
        if FES1 + FES2 <= 10000*D
            vysl05pop(krok, :) = [fmin, violmin, GH, xmin];
        end
        fprintf(fid,'%-15s', 'LSH44IDE');
        fprintf(fid,'%4.0f %4.0f %4.0f', fnum, d, nasobek);
        fprintf(fid,'%5.0f ', rnumfeas);
        % fprintf(fid,'%6.2f %6.2f %10.2e', rFESviol, rfeas, eps_fun);
        fprintf(fid, '%4.0f  ', krok);
        fprintf(fid,'%5.0f',num_feasible);
        fprintf(fid,' %15.4e %15.4e', fmin1, violmin1);
        fprintf(fid,' %15.4e %15.4e', fmin, violmin);
        fprintf(fid,'%8.0f %8.0f ', FES1+FES2, FES1);
        %         fprintf(fid,'%8.0f %8.4f', success1, success1/FES1 );
        fprintf(fid,'%8.0f %8.4f', success2, success2/FES2 );
        if sum(GH) > 0
            for j=1:9
                fprintf(fid,'%12.3g', GH(j));
            end
        end
        fprintf(fid,'%1s\n',' ');
    end
    fclose(fid);
    jm_mat01=['lsh_d', num2str(d), '_', num2str(fnum), '_01' ];
    save(jm_mat01, 'vysl01pop')
    jm_mat05=['lsh_d', num2str(d), '_', num2str(fnum), '_05' ];
    save(jm_mat05, 'vysl05pop')
    jm_matfin=['lsh_d', num2str(d), '_', num2str(fnum), '_fin' ];
    save(jm_matfin, 'vyslfinpop')
end
